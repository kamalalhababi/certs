Initial setup scripts

sudo su
sudo apt update


To set up a startup service on a Linux system using systemd, you'll need to create a new service file and enable it so it starts automatically when the system boots. Here's a step-by-step guide to accomplish this:

### 1. Create the Service File
First, you need to create a systemd service file for your script. This file will contain the configuration you've provided.

1. **Open a terminal** on your Linux system.
2. Use a text editor to create a new service file under the `/etc/systemd/system` directory. For example, let's name your service `mycustomstartup.service`. You can use any text editor; here, I'll use `nano`:
    ```bash
    sudo nano /etc/systemd/system/mycustomstartup.service
    ```
3. Paste your service configuration into the editor:
    ```
    [Unit]
    Description=My custom startup script
    After=network.target

    [Service]
    ExecStart=/home/certigeni/cert_startup.sh
    User=root
    Group=root
    Type=simple
    Restart=on-failure
    RestartSec=5s

    [Install]
    WantedBy=multi-user.target
    ```
4. Save the file and exit the editor. If you're using `nano`, you can do this by pressing `Ctrl + O`, `Enter`, and then `Ctrl + X`.

### 2. Make the Script Executable
Ensure that your script (`/home/certigeni/cert_startup.sh`) is executable.

```bash
sudo chmod +x /home/certigeni/cert_startup.sh
```

### 3. Reload Systemd
After creating the service file, reload systemd to recognize your new service:

```bash
sudo systemctl daemon-reload
```

### 4. Enable the Service
To have your service start automatically at boot, enable it:

```bash
sudo systemctl enable mycustomstartup.service
```

### 5. Start the Service
To start your service immediately without rebooting:

```bash
sudo systemctl start mycustomstartup.service
```

### 6. Verify the Service Status
Check the status of your service to ensure it's active and running:

```bash
sudo systemctl status mycustomstartup.service
```

### Troubleshooting
If the service doesn't start as expected, you can check its logs for errors:

```bash
sudo journalctl -u mycustomstartup.service
```

### Additional Considerations
- **Security**: Running scripts as root can be risky. If possible, consider running your script as a non-root user unless absolutely necessary.
- **Script Permissions**: Ensure your script has the correct permissions and that it's secure, especially if running as root.
- **Environment**: If your script relies on environment variables, you might need to explicitly set them in your service file.

By following these steps, you should have your startup service configured and running on your Linux system.
